# Normalization
Normalization of  table 
